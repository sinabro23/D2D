#include "PreCompile.h"
#include "$safeitemname$.h"

// Static Var
// Static Func

// constructer destructer
$safeitemname$::$safeitemname$()
{
}

$safeitemname$::~$safeitemname$()
{
}

$safeitemname$::$safeitemname$($safeitemname$&& _other) noexcept
{
}

//member Func
