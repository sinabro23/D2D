#include "PreCompile.h"
#include "$safeitemname$Manager.h"
#include "$safeitemname$.h"

$safeitemname$Manager::$safeitemname$Manager() // default constructer ����Ʈ ������
{

}

$safeitemname$Manager::~$safeitemname$Manager() // default destructer ����Ʈ �Ҹ���
{
	for (const std::pair<std::string, $safeitemname$*>& Res : ResourcesMap)
	{
		if (nullptr != Res.second)
		{
			delete Res.second;
		}
	}

	ResourcesMap.clear();
}

$safeitemname$Manager::$safeitemname$Manager($safeitemname$Manager&& _other) noexcept  // default RValue Copy constructer ����Ʈ RValue ���������
{

}



$safeitemname$* $safeitemname$Manager::Create(const std::string& _Name)
{
	$safeitemname$* FindRes = Find(_Name);

	if (nullptr != FindRes)
	{
		GameEngineDebug::MsgBoxError(_Name + " Is Overlap Load");
	}


	$safeitemname$* NewRes = new $safeitemname$();
	NewRes->SetName(_Name);

	// �׸��� ���Ұų�?

	ResourcesMap.insert(std::map<std::string, $safeitemname$*>::value_type(_Name, NewRes));
}

$safeitemname$* $safeitemname$Manager::Load(const std::string& _Path)
{
	return Load(GameEnginePath::GetFileName(_Path), _Path);
}

$safeitemname$* $safeitemname$Manager::Load(const std::string& _Name, const std::string& _Path)
{
	$safeitemname$* FindRes = Find(_Name);

	if (nullptr != FindRes)
	{
		GameEngineDebug::MsgBoxError(_Name + " Is Overlap Load");
	}

	$safeitemname$* NewRes = new $safeitemname$();
	NewRes->SetName(_Name);


	ResourcesMap.insert(std::map<std::string, $safeitemname$*>::value_type(_Name, NewRes));
}

$safeitemname$* $safeitemname$Manager::Find(const std::string& _Name)
{
	std::map<std::string, $safeitemname$*>::iterator FindIter = ResourcesMap.find(_Name);

	if (FindIter != ResourcesMap.end())
	{
		return FindIter->second;
	}

	return nullptr;
}